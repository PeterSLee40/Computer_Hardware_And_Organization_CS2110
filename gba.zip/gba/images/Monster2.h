/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 Monster2 Monster2.png 
 * Time-stamp: Sunday 11/18/2018, 14:10:19
 * 
 * Image Information
 * -----------------
 * Monster2.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MONSTER2_H
#define MONSTER2_H

extern const unsigned short Monster2[400];
#define MONSTER2_SIZE 800
#define MONSTER2_LENGTH 400
#define MONSTER2_WIDTH 20
#define MONSTER2_HEIGHT 20

#endif

