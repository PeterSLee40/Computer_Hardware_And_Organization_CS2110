/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 Monster3 Monster3.png 
 * Time-stamp: Sunday 11/18/2018, 14:10:11
 * 
 * Image Information
 * -----------------
 * Monster3.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MONSTER3_H
#define MONSTER3_H

extern const unsigned short Monster3[400];
#define MONSTER3_SIZE 800
#define MONSTER3_LENGTH 400
#define MONSTER3_WIDTH 20
#define MONSTER3_HEIGHT 20

#endif

