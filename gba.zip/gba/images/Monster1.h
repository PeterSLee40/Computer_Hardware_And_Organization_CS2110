/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 monster1 Monster1.png 
 * Time-stamp: Thursday 11/15/2018, 17:41:45
 * 
 * Image Information
 * -----------------
 * Monster1.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MONSTER1_H
#define MONSTER1_H

extern const unsigned short Monster1[400];
#define MONSTER1_SIZE 800
#define MONSTER1_LENGTH 400
#define MONSTER1_WIDTH 20
#define MONSTER1_HEIGHT 20

#endif

