/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 Monster3 putin.jpg 
 * Time-stamp: Tuesday 11/20/2018, 20:03:56
 * 
 * Image Information
 * -----------------
 * putin.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MONSTER3_H
#define MONSTER3_H

extern const unsigned short putin[400];
#define PUTIN_SIZE 800
#define PUTIN_LENGTH 400
#define PUTIN_WIDTH 20
#define PUTIN_HEIGHT 20

#endif

