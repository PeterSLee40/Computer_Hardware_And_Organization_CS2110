/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 bigtrump trump.png 
 * Time-stamp: Thursday 11/15/2018, 14:17:46
 * 
 * Image Information
 * -----------------
 * trump.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIGTRUMP_H
#define BIGTRUMP_H

extern const unsigned short trump[400];
#define TRUMP_SIZE 800
#define TRUMP_LENGTH 400
#define TRUMP_WIDTH 20
#define TRUMP_HEIGHT 20

#endif

