#ifndef GRAPHICS_SEEN
#define GRAPHICS_SEEN

#include "logic.h"

//static void drawMonster1(Monster1* monster1);

//start state
void drawStartState(AppState *state);
// This function will be used to draw everything about the state of your app
// including the background and whatnot.
void fullDrawAppState(AppState *state);

// This function will be used to undraw (i.e. erase) things that might
// move in a frame. E.g. in a Snake game, erase the Snake, the food & the score.
void undrawAppState(AppState *state);

// This function will be used to draw things that might have moved in a frame.
// For example, in a Snake game, draw the snake, the food, the score.
void drawAppState(AppState *state);

// this draws the win or loss conditions
void drawWin(AppState *state);
void drawLoss(AppState *state);
// If you have anything else you need accessible from outside the graphics.c
// file, you can add them here. You likely won't.

#endif
