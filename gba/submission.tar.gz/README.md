Name : Peter Lee, plee99

The program's name is Klaus House. 
Your Character is in charge of all of CoC however
it is under attack and you need to use your green
light saber to defeat the monsters!

Use the array keys to move and B to attack:
Left button  - 	move left
Right button - 	move right
Up Button    - 	jump
Down Button  - 	crouch
A Button     -  Throw brick
B Button     -  Sword attack